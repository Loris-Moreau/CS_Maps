#pragma once
#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "UObject/SoftObjectPath.h"
#include "AnyMetaSettings.generated.h"

USTRUCT()
struct FAnyMetaForProperty
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, Category="PyToolkit|AnyMeta")
    TMap<FName, FString> Meta;

    UPROPERTY(EditAnywhere, Category="PyToolkit|AnyMeta")
    FString EditCondition; // "bX" or "!bX"
};

USTRUCT()
struct FAnyMetaForObject
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, Category="PyToolkit|AnyMeta")
    TMap<FName, FAnyMetaForProperty> ByProperty;
};

UCLASS(config=EditorPerProjectUserSettings)
class PYTOOLKIT_API UAnyMetaSettings : public UObject
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, config, Category="PyToolkit|AnyMeta")
    TMap<FSoftObjectPath, FAnyMetaForObject> Overlays;

    static UAnyMetaSettings* Get();

    bool Get(const UObject* Obj, FName Prop, FAnyMetaForProperty& Out) const;
    void Put(const UObject* Obj, FName Prop, const FAnyMetaForProperty& In);
    void Save();
};
