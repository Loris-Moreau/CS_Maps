// Copyright Epic Games, Inc. All Rights Reserved.
#pragma once
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CoreMinimal.h"
#include "Runtime/LevelSequence/Public/LevelSequence.h"
#include "MovieSceneTrack.h"
#include "MovieScene.h" // For FGuid
#include "Runtime/Engine/Classes/Engine/TextureRenderTargetCube.h"
#include "Runtime/Engine/Classes/Engine/TextureCube.h"
#include "Engine/SkeletalMeshSocket.h"
#include "Runtime/Engine/Classes/Animation/Skeleton.h"
#include "Materials/MaterialInterface.h"
#include "MaterialEditingLibrary.h"
#include "Engine/Engine.h" // Often useful for common types like FLinearColor
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialInstance.h"
#include "Materials/Material.h"
#include "MaterialEditor/MaterialEditorInstanceConstant.h" // Used in GetMaterialEditorSourceInstance
#include "Engine/Texture2D.h"
#include "Engine/Texture2DArray.h"
#include "Tracks/MovieSceneParticleTrack.h"
#include "Sections/MovieSceneParticleSection.h"
#include "Animation/AnimSequence.h"
#include "Sections/MovieSceneSkeletalAnimationSection.h"

#include "ContentBrowserModule.h"
#include "Modules/ModuleManager.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "IKeyArea.h"


// Forward declarations for types used in function signatures but not fully defined here
class UObject;
class UClass;
class AActor;
class USceneComponent;
class UActorComponent;
class UFunction;

#include "PyToolkitBPLibrary.generated.h"

/*
 *	Function library class.
 *	Each function in it is expected to be static and represents blueprint node that can be called in any blueprint.
 *
 *	When declaring function you can define metadata for the node. Key function specifiers will be BlueprintPure and BlueprintCallable.
 *	BlueprintPure - means the function does not affect the owning object in any way and thus creates a node without Exec pins.
 *	BlueprintCallable - makes a function which can be executed in Blueprints - Thus it has Exec pins.
 *	DisplayName - full name of the node, shown when you mouse over the node and in the blueprint drop down menu.
 *				Its lets you name the node using characters not allowed in C++ function names.
 *	CompactNodeTitle - the word(s) that appear on the node.
 *	Keywords -	the list of keywords that helps you to find node when you search for it using Blueprint drop-down menu.
 *				Good example is "Print String" node which you can find also by using keyword "log".
 *	Category -	the category your node will be under in the Blueprint drop-down menu.
 *
 *	For more info on custom blueprint nodes visit documentation:
 *	https://wiki.unrealengine.com/Custom_Blueprint_Node_Creation
 */

UENUM(BlueprintType)
	enum class EBPEditorOutputBranch : uint8
	{
		outTrue,
		outFalse
	};

UENUM(BlueprintType)
enum class EState : uint8
{
	Success = 0,
	Pending,
	Fail,
	None
};

UENUM(BlueprintType)
enum class ESeverity : uint8
{
	Info = 0,
	Warning,  
	PerformanceWarning,  
	Error
};

UCLASS()
class UPyToolkitBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

	// UFUNCTION(BlueprintCallable, meta = (DisplayName = "Execute Sample function", Keywords = "PyToolkit sample test testing"), Category = "PyToolkitTesting")
	// static float PyToolkitSampleFunction(float Param);

#pragma region UnrealPythonLibrary
	// copy from https://github.com/AlexQuevillon/UnrealPythonLibrary
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static TArray<UObject *> GetAllObjects();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static TArray<FString> GetAllProperties(UClass *Class);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static TArray<FString> GetSelectedFolders();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static void SetSelectedAssets(TArray<FString> Paths);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static void SetSelectedFolders(TArray<FString> Paths);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static void CloseEditorForAssets(TArray<UObject *> Assets);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static TArray<UObject *> GetAssetsOpenedInEditor();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static void SetFolderColor(FString FolderPath, FLinearColor Color);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static void SetViewportLocationAndRotation(int ViewportIndex, FVector Location, FRotator Rotation);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Lib")
	static int GetActiveViewportIndex();

#pragma endregion

#pragma region SequencerAPI

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static ULevelSequence *GetSequencerSequence();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static TArray<FGuid> GetSequencerSelectedID(ULevelSequence *LevelSeq);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static TArray<UMovieSceneTrack *> GetSequencerSelectedTracks(ULevelSequence *LevelSeq);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static TSet<UMovieSceneSection *> GetSequencerSelectedSections(ULevelSequence *LevelSeq);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static TMap<UMovieSceneSection *, FString> GetSequencerSelectedChannels(ULevelSequence *LevelSeq);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI", meta = (DisplayName = "Add Particle Trigger Key"))
	static void AddParticleTriggerKey(UMovieSceneParticleSection* MovieSceneParticleSection, FFrameNumber InTime);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static void AddParticleKey(UMovieSceneParticleSection* MovieSceneParticleSection, FFrameNumber ActivateTime, FFrameNumber DeactivateTime);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|SequencerAPI")
	static void SetAnimationSectionWeight(UMovieSceneSkeletalAnimationSection* AnimSection, float Weight=1);


#pragma endregion

#pragma region SocketAPI
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Socket")
	static USkeletalMeshSocket *AddSkeletalMeshSocket(USkeleton *InSkeleton, FName InBoneName);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Socket")
	static void DeleteSkeletalMeshSocket(USkeleton *InSkeleton, TArray<USkeletalMeshSocket *> SocketList);
#pragma endregion

#pragma region SkeletonAPI
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static int32 GetSkeletonBoneNum(USkeleton *InSkeleton);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static FName GetSkeletonBoneName(USkeleton *InSkeleton, int32 BoneIndex);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static int32 GetSkeletonBoneIndex(USkeleton *InSkeleton, FName BoneName);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static TArray<FName> GetSkeletonBoneChildren(USkeleton *InSkeleton, FName BoneName);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static bool BoneExistInSkeletalMesh(USkeletalMesh* SkeletalMesh, const FName& BoneName);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static TArray<FName> GetAllSkeletalMeshBones(USkeletalMesh* SkeletalMesh);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Skeleton")
	static TArray<FName> GetAllSkeletonBones(const USkeleton* Skeleton);

#pragma endregion

#pragma region Material>

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static UMaterialInstanceConstant *GetMaterialEditorSourceInstance(UMaterialEditorInstanceConstant *Editor);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static void SetMaterialInstanceStaticSwitchParameterValue(UMaterialInstance *Instance, FName ParameterName, bool SwitchValue, bool bOverride);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static void SetMaterialInstanceComponentMaskParameter(UMaterialInstance *Instance, FName ParameterName, bool InR, bool InG, bool InB, bool InA, bool bOverride);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static void GetComponentMasksNames(UMaterialInterface* Material, TArray<FName>& ParameterNames);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static void ForceRecompileMaterialInstance(UMaterialInstance* MaterialInstance);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Material")
	static bool GetStaticComponentMaskParameterValue(UMaterialInstance* Instance, FName ParameterName, EMaterialParameterAssociation Association, bool& R, bool& G, bool& B, bool& A, FGuid& OutExpressionGuid, bool bOveriddenOnly);

	/** True if the named static switch is overridden on this Material Instance (vs. inherited from parent). */
	UFUNCTION(CallInEditor, BlueprintCallable, Category="PyToolkit|Material|StaticSwitch")
	static bool IsStaticSwitchOverridden(UMaterialInstance* Instance, FName ParameterName);

	/** Collect all overridden static switch parameter names on this Material Instance. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category="PyToolkit|Material|StaticSwitch")
	static void GetOverriddenStaticSwitches(UMaterialInstance* Instance, TArray<FName>& OutOverridden);

	/** Clear the override on a single static switch, making the Instance inherit its parent value. Returns true if a change was made. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category="PyToolkit|Material|StaticSwitch")
	static bool ResetStaticSwitchToDefault(UMaterialInstance* Instance, FName ParameterName, bool bMarkDirtyAsset = true);

	/** Clear overrides on ALL static switches for this Instance. Returns number of switches changed. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category="PyToolkit|Material|StaticSwitch")
	static int32 ResetAllOverriddenStaticSwitches(UMaterialInstance* Instance, bool bMarkDirtyAsset = true);


#pragma endregion

#pragma region Texture

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Texture")
	static UTextureCube* RenderTargetCubeCreateStaticTextureCube(UTextureRenderTargetCube* RenderTarget, FString InName);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Texture")
	static bool TextureHasAlphaChannel(UTexture2D* Texture2D);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Texture")
	static void GetTextureSize(UTexture2D* Texture2D, int32& X, int32& Y);
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Texture")
	static void AddTexture2DArray(UTexture2DArray* Texture2DArray, TArray<UTexture2D*> Textures);

#pragma endregion
#pragma region Msic

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Msic")
	static UActorComponent *AddComponent(AActor *a, USceneComponent *future_parent, FName name, UClass *NewComponentClass);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Msic")
	static TArray<uint8> GetThumbnail(UObject *MeshObject, int32 _imageRes = 128);

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Msic")
	static void RunFunction(UObject *CDO, UFunction *Function);

#pragma endregion

#pragma region Notification
	
	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|Notification")
	static void ShowNotification(FString NotificationText, float ExpireDuration=5, bool bUseLargeFont=false, EState CompletionState=EState::Success);

#pragma endregion

#pragma region MessageLog

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void RegisterWidgetMessageLog();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void ResetWidgetMessageLog(FString PageName="NewPage");

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void OpenWidgetMessageLog();

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void AddSimpleMessageToWidgetMessageLog(FString Message, ESeverity Severity=ESeverity::Info, bool ShowNotification=false, FString NotificationText="Notification");

	UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void ShowNotificationWidgetMessageLog(FString Message, ESeverity Severity, bool ForceNotify);

    UFUNCTION(BlueprintCallable, Category = "PyToolkit|Editor|MessageLog")
	static void LogActorMaterialWarning(AActor* Actor, UMaterialInterface* Material, const FString& AdditionalMessage);

#pragma endregion
};

USTRUCT(BlueprintType)
struct FDPath
{
	GENERATED_BODY()

	/**
	 * The path to the directory.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = ContentPath, meta = (ContentDir))
	FDirectoryPath DirectoryContentPath;
};