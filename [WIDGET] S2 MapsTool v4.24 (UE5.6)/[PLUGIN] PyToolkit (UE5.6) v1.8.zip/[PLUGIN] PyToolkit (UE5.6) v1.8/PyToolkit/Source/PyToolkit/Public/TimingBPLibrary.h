#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "TimingBPLibrary.generated.h"

// Single log category for timing output
DECLARE_LOG_CATEGORY_EXTERN(LogPyToolkit, Log, All);

UCLASS()
class PYTOOLKIT_API UTimingBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Begin a named timing scope (supports nesting). If bLogStart=true, prints a "started" line now and a matching "finished" line on Finish. */
	UFUNCTION(BlueprintCallable, Category="PyToolkit|Timing")
	static void StartTimedSection(FName Name, bool bLogStart = false);

	/** End the most-recent open scope with this Name. Returns elapsed seconds. */
	UFUNCTION(BlueprintCallable, Category="PyToolkit|Timing")
	static float FinishTimedSection(FName Name);

	/** Log aggregated counts + total time for each Name. */
	UFUNCTION(BlueprintCallable, Category="PyToolkit|Timing")
	static void LogTimedStats();

	/** Clear all timing data (open scopes and aggregates). */
	UFUNCTION(BlueprintCallable, Category="PyToolkit|Timing")
	static void ResetTimedStats();
};
