#pragma once
#include "CoreMinimal.h"

struct FEditConditionEvaluator
{
    static bool Evaluate(const UObject* Obj, const FString& Expr);
};
