#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "VarByNameLite.generated.h"

/**
 * Assigns properties by name on any live UObject (e.g., EUW Self).
 * Returns true on success (property exists & type compatible).
 */

UCLASS()
class PYTOOLKIT_API UVarByNameLite : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    // Numerics
    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetFloatPropertyByName(UObject* Target, FName PropertyName, float Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetDoublePropertyByName(UObject* Target, FName PropertyName, double Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetIntPropertyByName(UObject* Target, FName PropertyName, int32 Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetBoolPropertyByName(UObject* Target, FName PropertyName, bool Value, bool bNotifyEditor = true);

    // Structs
    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetVectorPropertyByName(UObject* Target, FName PropertyName, FVector Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetLinearColorPropertyByName(UObject* Target, FName PropertyName, FLinearColor Value, bool bNotifyEditor = true);

    // Textures
    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetTexturePropertyByName(UObject* Target, FName PropertyName, UTexture* Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetTexture2DPropertyByName(UObject* Target, FName PropertyName, UTexture2D* Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetTexture2DArrayPropertyByName(UObject* Target, FName PropertyName, UTexture2DArray* Value, bool bNotifyEditor = true);
    
    // Generic object & strings
    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetObjectPropertyByName(UObject* Target, FName PropertyName, UObject* Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetStringPropertyByName(UObject* Target, FName PropertyName, const FString& Value, bool bNotifyEditor = true);

    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Set", meta=(DefaultToSelf="Target", AdvancedDisplay="bNotifyEditor"))
    static bool SetNamePropertyByName(UObject* Target, FName PropertyName, FName Value, bool bNotifyEditor = true);

    // --- Getters
    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetFloatPropertyByName(UObject* Target, FName PropertyName, bool& bFound, float& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetDoublePropertyByName(UObject* Target, FName PropertyName, bool& bFound, double& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetIntPropertyByName(UObject* Target, FName PropertyName, bool& bFound, int32& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetBoolPropertyByName(UObject* Target, FName PropertyName, bool& bFound, bool& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetVectorPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FVector& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetLinearColorPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FLinearColor& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetTexturePropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture*& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetTexture2DPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture2D*& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetTexture2DArrayPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture2DArray*& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetObjectPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UObject*& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetStringPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FString& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetNamePropertyByName(UObject* Target, FName PropertyName, bool& bFound, FName& Value);

    UFUNCTION(BlueprintPure, Category="PyToolkit|VarByName|Get", meta=(DefaultToSelf="Target"))
    static void GetPropertyTypeByName(UObject* Target, FName PropertyName, bool& bFound, FString& TypeName);

    /** Returns the variable/property name of whatever is connected to the wildcard pin. */
    UFUNCTION(BlueprintPure, CustomThunk, Category="PyToolkit|VarByName", meta=(DisplayName="Get Variable Name", CustomStructureParam="Var"))
    static void GetPropertyName(const int32& Var, /*wildcard*/ bool& bFound, FName& PropertyName);

    DECLARE_FUNCTION(execGetPropertyName);

    /** Reset only properties that differ from class defaults (CDO). */
    UFUNCTION(BlueprintCallable, Category="PyToolkit|VarByName|Reset", meta=(DisplayName="Reset Dirty Properties", DefaultToSelf="Target", AdvancedDisplay="bIncludeTransient,bDuplicateInstancedSubobjects"))
    static void ResetDirtyProperties(UObject* Target, bool bIncludeTransient /*= true*/,bool bDuplicateInstancedSubobjects /*= true*/);
};
