#include "Widgets/Input/STextComboBox.h"
#pragma once
#include "IDetailCustomization.h"
#include "Templates/SharedPointer.h"

class FAnyMetaCustomization : public IDetailCustomization
{
public:
    
	
	void BuildQuickEditConditions(class IDetailLayoutBuilder& DetailBuilder);
	static TSharedRef<IDetailCustomization> MakeInstance();
    virtual void CustomizeDetails(class IDetailLayoutBuilder& DetailBuilder) override;

private:
    
	TSharedPtr<class STextComboBox> ChildCombo;
	TSharedPtr<class STextComboBox> ParentCombo;
	TSharedPtr<TArray<TSharedPtr<FString>>> VarOptions;
	void ApplyOverlays(class IDetailLayoutBuilder& DetailBuilder, const TArray<TWeakObjectPtr<UObject>>& Objects);
    void BuildEditorUI(class IDetailLayoutBuilder& DetailBuilder, const TArray<TWeakObjectPtr<UObject>>& Objects);
    void WriteToBlueprintIfPossible(UObject* Obj, FName PropName, const TMap<FName,FString>& Meta, const FString& EditCond);
};
