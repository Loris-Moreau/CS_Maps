// Copyright Epic Games, Inc. All Rights Reserved.

#include "PyToolkitBPLibrary.h"
#include "PyToolkit.h"
#include "Materials/MaterialExpression.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstance.h"
#include "Sections/MovieSceneParticleSection.h"
#include "Tracks/MovieSceneParticleTrack.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

#include "IContentBrowserSingleton.h"
#include "LevelEditorViewport.h" // For FLevelEditorViewportClient
#include "ILevelSequenceEditorToolkit.h" // For ILevelSequenceEditorToolkit
#include "ISequencer.h" // For ISequencer
#include "ISkeletonEditorModule.h" // For ISkeletonEditorModule
#include "IEditableSkeleton.h" // For IEditableSkeleton
#include "AssetToolsModule.h" // For IAssetTools and FAssetToolsModule
#include "PackageTools.h" // For UPackageTools
#include "MessageLogModule.h" // For FMessageLogModule
#include "ObjectTools.h"
#include "Misc/UObjectToken.h"

#define LOCTEXT_NAMESPACE "PyToolkitBPLibrary"
   

UPyToolkitBPLibrary::UPyToolkitBPLibrary(const FObjectInitializer &ObjectInitializer)
    : Super(ObjectInitializer)
{
} 

#pragma region UnrealPythonLibrary
// copy from https://github.com/AlexQuevillon/UnrealPythonLibrary

TArray<UObject *> UPyToolkitBPLibrary::GetAllObjects()
{
    TArray<UObject *> Array;
    for (TObjectIterator<UObject> Itr; Itr; ++Itr)
    {
        Array.Add(*Itr);
    }
    return Array;
}

TArray<FString> UPyToolkitBPLibrary::GetAllProperties(UClass *Class)
{
    TArray<FString> Ret;
    if (Class != nullptr)
    {
        for (TFieldIterator<FProperty> It(Class); It; ++It)
        {
            FProperty *Property = *It;
            if (Property->HasAnyPropertyFlags(EPropertyFlags::CPF_Edit))
            {
                Ret.Add(Property->GetName());
            }
        }
    }
    return Ret;
}

void UPyToolkitBPLibrary::SetSelectedAssets(TArray<FString> Paths)
{
    FContentBrowserModule &ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
    FAssetRegistryModule &AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
    TArray<FName> PathsName;
    for (FString Path : Paths)
    {
        PathsName.Add(*Path);
    }
    FARFilter AssetFilter;
    AssetFilter.PackageNames = PathsName;
    TArray<FAssetData> AssetDatas;
    AssetRegistryModule.Get().GetAssets(AssetFilter, AssetDatas);
    ContentBrowserModule.Get().SyncBrowserToAssets(AssetDatas);
}

TArray<FString> UPyToolkitBPLibrary::GetSelectedFolders()
{
    FContentBrowserModule &ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
    TArray<FString> SelectedFolders;
    ContentBrowserModule.Get().GetSelectedFolders(SelectedFolders);
    return SelectedFolders;
}

void UPyToolkitBPLibrary::SetSelectedFolders(TArray<FString> Paths)
{
    FContentBrowserModule &ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
    ContentBrowserModule.Get().SyncBrowserToFolders(Paths);
}

void UPyToolkitBPLibrary::CloseEditorForAssets(TArray<UObject *> Assets)
{
    // NOTE 源码的方式已经过时，推荐用 SubSystem 的方式
    UAssetEditorSubsystem *sub = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
    for (UObject *Asset : Assets)
    {
        sub->CloseAllEditorsForAsset(Asset);
    }
}

TArray<UObject *> UPyToolkitBPLibrary::GetAssetsOpenedInEditor()
{
    UAssetEditorSubsystem *sub = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
    return sub->GetAllEditedAssets();
}

void UPyToolkitBPLibrary::SetFolderColor(FString FolderPath, FLinearColor Color)
{
    GConfig->SetString(TEXT("PathColor"), *FolderPath, *Color.ToString(), GEditorPerProjectIni);
}

int UPyToolkitBPLibrary::GetActiveViewportIndex()
{
    int Index = 1;
    if (GEditor != nullptr && GCurrentLevelEditingViewportClient != nullptr)
    {
        GEditor->GetLevelViewportClients().Find(GCurrentLevelEditingViewportClient, Index);
    }
    return Index;
}

// ViewportIndex is affected by the spawning order and not the viewport number.
//    e.g. Viewport 4 can be the first one if the user spawned it first.
//         And can become the last one if the user open the other ones and then close and re-open Viewport 4.
//    Also, the indexes are confusing.
// 1st Spawned Viewport : Index = 1
// 2nd Spawned Viewport : Index = 5
// 3rd Spawned Viewport : Index = 9
// 4th Spawned Viewport : Index = 13
void UPyToolkitBPLibrary::SetViewportLocationAndRotation(int ViewportIndex, FVector Location, FRotator Rotation)
{
    if (GEditor != nullptr && ViewportIndex < GEditor->GetLevelViewportClients().Num())
    {
        FLevelEditorViewportClient *LevelViewportClient = GEditor->GetLevelViewportClients()[ViewportIndex];
        if (LevelViewportClient != nullptr)
        {
            LevelViewportClient->SetViewLocation(Location);
            LevelViewportClient->SetViewRotation(Rotation);
        }
    }
}

#pragma region SequencerAPI

ULevelSequence *UPyToolkitBPLibrary::GetSequencerSequence()
{
    UAssetEditorSubsystem *sub = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
    TArray<UObject *> assets = sub->GetAllEditedAssets();

    for (UObject *asset : assets)
    {
        // Get LevelSequenceEditor

        IAssetEditorInstance *AssetEditor = sub->FindEditorForAsset(asset, false);
        ILevelSequenceEditorToolkit *LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);

        if (LevelSequenceEditor != nullptr)
        {
            ULevelSequence *LevelSeq = Cast<ULevelSequence>(asset);
            return LevelSeq;
        }
    }

    return nullptr;
}

TArray<FGuid> UPyToolkitBPLibrary::GetSequencerSelectedID(ULevelSequence *LevelSeq)
{
    IAssetEditorInstance *AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSeq, false);

    ILevelSequenceEditorToolkit *LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);

    TArray<FGuid> SelectedGuid;
    if (LevelSequenceEditor != nullptr)
    {
        // Get current Sequencer
        ISequencer *Sequencer = LevelSequenceEditor->GetSequencer().Get();

        Sequencer->GetSelectedObjects(SelectedGuid);
    }

    return SelectedGuid;
}

TArray<UMovieSceneTrack *> UPyToolkitBPLibrary::GetSequencerSelectedTracks(ULevelSequence *LevelSeq)
{
    IAssetEditorInstance *AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSeq, false);

    ILevelSequenceEditorToolkit *LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);

    TArray<UMovieSceneTrack *> OutSelectedTracks;
    if (LevelSequenceEditor != nullptr)
    {
        // Get current Sequencer
        ISequencer *Sequencer = LevelSequenceEditor->GetSequencer().Get();

        Sequencer->GetSelectedTracks(OutSelectedTracks);
    }

    return OutSelectedTracks;
}

TSet<UMovieSceneSection *> UPyToolkitBPLibrary::GetSequencerSelectedSections(ULevelSequence *LevelSeq)
{
    IAssetEditorInstance *AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSeq, false);
    ILevelSequenceEditorToolkit *LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);

    TArray<const IKeyArea *> KeyAreaArray;
    TSet<UMovieSceneSection *> OutSelectedSections;
    if (LevelSequenceEditor != nullptr)
    {
        ISequencer *Sequencer = LevelSequenceEditor->GetSequencer().Get();
        Sequencer->GetSelectedKeyAreas(KeyAreaArray);
        for (const IKeyArea *KeyArea : KeyAreaArray)
        {
            OutSelectedSections.Add(KeyArea->GetOwningSection());
        }
    }
    return OutSelectedSections;
}

TMap<UMovieSceneSection *, FString> UPyToolkitBPLibrary::GetSequencerSelectedChannels(ULevelSequence *LevelSeq)
{
    IAssetEditorInstance *AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSeq, false);
    ILevelSequenceEditorToolkit *LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);

    TMap<UMovieSceneSection *, FString> OutMap;
    TArray<FString> KeyAreaNames;
    TArray<const IKeyArea *> KeyAreaArray;
    if (LevelSequenceEditor != nullptr)
    {
        ISequencer *Sequencer = LevelSequenceEditor->GetSequencer().Get();
        Sequencer->GetSelectedKeyAreas(KeyAreaArray);
        for (const IKeyArea *KeyArea : KeyAreaArray)
        {
            UMovieSceneSection *Section = KeyArea->GetOwningSection();
            if (OutMap.Contains(Section))
            {
                OutMap[Section] += "|" + KeyArea->GetName().ToString();
            }
            else
            {
                OutMap.Emplace(Section, KeyArea->GetName().ToString());
            }
            // KeyAreaNames.Add(KeyArea->GetName().ToString());
        }
    }
    return OutMap;
}

void UPyToolkitBPLibrary::AddParticleTriggerKey(UMovieSceneParticleSection* MovieSceneParticleSection, FFrameNumber InTime)
{
    EParticleKey  ParticleKeyState = EParticleKey::Trigger;
    
    UMovieScene* MovieScene = MovieSceneParticleSection->GetTypedOuter<UMovieScene>();
    if (MovieScene)
    {
        int32 TickResolution = MovieScene->GetTickResolution().Numerator;
        int32 DisplayRate = MovieScene->GetDisplayRate().Numerator;
        InTime = InTime * TickResolution / DisplayRate;
        FMovieSceneParticleChannel* Channel = MovieSceneParticleSection->GetChannelProxy().GetChannel<FMovieSceneParticleChannel>(0);
        Channel->GetData().AddKey(InTime, (uint8)ParticleKeyState);
    }
}

void UPyToolkitBPLibrary::AddParticleKey(UMovieSceneParticleSection* MovieSceneParticleSection, FFrameNumber ActivateTime, FFrameNumber DeactivateTime)
{
    EParticleKey  ParticleKeyActivate = EParticleKey::Activate;
    EParticleKey  ParticleKeyDectivate = EParticleKey::Deactivate;
    
    UMovieScene* MovieScene = MovieSceneParticleSection->GetTypedOuter<UMovieScene>();
    if (MovieScene)
    {
        int32 TickResolution = MovieScene->GetTickResolution().Numerator;
        int32 DisplayRate = MovieScene->GetDisplayRate().Numerator;
        ActivateTime = ActivateTime * TickResolution / DisplayRate;
        DeactivateTime = DeactivateTime * TickResolution / DisplayRate;
        FMovieSceneParticleChannel* Channel = MovieSceneParticleSection->GetChannelProxy().GetChannel<FMovieSceneParticleChannel>(0);
        Channel->GetData().AddKey(ActivateTime, (uint8)ParticleKeyActivate);
        Channel->GetData().AddKey(DeactivateTime, (uint8)ParticleKeyDectivate);
    }
}

void UPyToolkitBPLibrary::SetAnimationSectionWeight(UMovieSceneSkeletalAnimationSection* AnimSection, float Weight)
{    
    if (!AnimSection) return; // Check if AnimSection is valid

    FMovieSceneSkeletalAnimationParams& AnimParams = AnimSection->Params;
    FMovieSceneFloatChannel& WeightChannel = AnimParams.Weight;
    WeightChannel.Reset();
    WeightChannel.SetDefault(Weight);

    AnimSection->Params = AnimParams;
}

#pragma endregion

#pragma region SocketAPI

USkeletalMeshSocket *UPyToolkitBPLibrary::AddSkeletalMeshSocket(USkeleton *InSkeleton, FName InBoneName)
{
    USkeletalMeshSocket *socket = nullptr;
    if (InSkeleton)
    {
        const FReferenceSkeleton& RefSkeleton = InSkeleton->GetReferenceSkeleton();
        const int32 BoneIndex = RefSkeleton.FindBoneIndex(InBoneName);
        if (BoneIndex != INDEX_NONE){
            InSkeleton->Modify();
            ISkeletonEditorModule &SkeletonEditorModule = FModuleManager::LoadModuleChecked<ISkeletonEditorModule>("SkeletonEditor");
            TSharedRef<IEditableSkeleton> EditableSkeleton = SkeletonEditorModule.CreateEditableSkeleton(InSkeleton);
            socket = EditableSkeleton->AddSocket(InBoneName);
        }
    }
    return socket;
}

void UPyToolkitBPLibrary::DeleteSkeletalMeshSocket(USkeleton *InSkeleton, TArray<USkeletalMeshSocket *> SocketList)
{
    if (!InSkeleton) return;
    InSkeleton->Modify();
    
    for (USkeletalMeshSocket *Socket : SocketList)
    {
        InSkeleton->Sockets.Remove(Socket);
    }
    ISkeletonEditorModule &SkeletonEditorModule = FModuleManager::LoadModuleChecked<ISkeletonEditorModule>("SkeletonEditor");
    TSharedRef<IEditableSkeleton> EditableSkeleton = SkeletonEditorModule.CreateEditableSkeleton(InSkeleton);
    EditableSkeleton->RefreshBoneTree();
}

#pragma endregion

#pragma region SkeletonAPI

int32 UPyToolkitBPLibrary::GetSkeletonBoneNum(USkeleton *InSkeleton)
{
    return InSkeleton->GetReferenceSkeleton().GetNum();
}

FName UPyToolkitBPLibrary::GetSkeletonBoneName(USkeleton *InSkeleton, int32 BoneIndex)
{
    return InSkeleton->GetReferenceSkeleton().GetBoneName(BoneIndex);
}

int32 UPyToolkitBPLibrary::GetSkeletonBoneIndex(USkeleton *InSkeleton, FName BoneName)
{
    if (!InSkeleton) return INDEX_NONE;
    
    const FReferenceSkeleton& RefSkeleton = InSkeleton->GetReferenceSkeleton();
    return RefSkeleton.FindBoneIndex(BoneName);
}

TArray<FName> UPyToolkitBPLibrary::GetSkeletonBoneChildren(USkeleton *InSkeleton, FName BoneName)
{
    TArray<FName> Ret;
    if (!InSkeleton) return Ret;
    
    const FReferenceSkeleton& RefSkeleton = InSkeleton->GetReferenceSkeleton();
    const int32 BoneIndex = RefSkeleton.FindBoneIndex(BoneName);
    
    if (BoneIndex != INDEX_NONE){
        const int32 NumBones = RefSkeleton.GetNum();
        for (int32 i = 0; i < NumBones; ++i)
        {
            int32 ParentIndex = RefSkeleton.GetParentIndex(i);
            if (ParentIndex == BoneIndex)
            {
                Ret.Add(RefSkeleton.GetBoneName(i));
            }
        }
    }

    return Ret;
}

bool UPyToolkitBPLibrary::BoneExistInSkeletalMesh(USkeletalMesh* SkeletalMesh, const FName& BoneName)
{
    if (!SkeletalMesh)
    {
        return false;
    }
    
    const USkeleton* Skeleton = SkeletalMesh->GetSkeleton();
    if (!Skeleton)
    {
        return false; // No skeleton associated with the mesh
    }
    const FReferenceSkeleton& SkeletonRefSkeleton = Skeleton->GetReferenceSkeleton();
    const FReferenceSkeleton& MeshRefSkeleton = SkeletalMesh->GetRefSkeleton();
    
    // Find the bone index in the skeleton
    int32 SkeletonBoneIndex = SkeletonRefSkeleton.FindBoneIndex(BoneName);
    if (SkeletonBoneIndex == INDEX_NONE)
    {
        return false; // Bone does not exist in the skeleton
    }
    
    // Check if the bone exists in the skeletal mesh
    int32 MeshBoneIndex = MeshRefSkeleton.FindBoneIndex(BoneName);
    return (MeshBoneIndex != INDEX_NONE);
}

TArray<FName> UPyToolkitBPLibrary::GetAllSkeletalMeshBones(USkeletalMesh* SkeletalMesh)
{
    TArray<FName> BoneNames;
    if (!SkeletalMesh)
    {
        return BoneNames;
    }
    
    const USkeleton* Skeleton = SkeletalMesh->GetSkeleton();
    if (!Skeleton)
    {
        return BoneNames;
    }
    
    const FReferenceSkeleton& MeshRefSkeleton = SkeletalMesh->GetRefSkeleton();
    for (int32 BoneIndex = 0; BoneIndex < MeshRefSkeleton.GetNum(); ++BoneIndex)
    {
        BoneNames.Add(MeshRefSkeleton.GetBoneName(BoneIndex));
    }
    return BoneNames;
}

TArray<FName> UPyToolkitBPLibrary::GetAllSkeletonBones(const USkeleton* Skeleton)
{
    TArray<FName> BoneNames;
    if (!Skeleton)
    {
        return BoneNames;
    }

    const FReferenceSkeleton& RefSkeleton = Skeleton->GetReferenceSkeleton();
    for (int32 BoneIndex = 0; BoneIndex < RefSkeleton.GetNum(); ++BoneIndex)
    {
        BoneNames.Add(RefSkeleton.GetBoneName(BoneIndex));
    }

    return BoneNames;
}

#pragma endregion

#pragma region Material

UMaterialInstanceConstant *UPyToolkitBPLibrary::GetMaterialEditorSourceInstance(UMaterialEditorInstanceConstant *Editor)
{
    return Editor->SourceInstance;
}

void UPyToolkitBPLibrary::SetMaterialInstanceStaticSwitchParameterValue(UMaterialInstance *Instance, FName ParameterName, bool SwitchValue, bool bOverride)
{
    TArray<FGuid> Guids;
    TArray<FMaterialParameterInfo> OutParameterInfo;
    Instance->GetAllStaticSwitchParameterInfo(OutParameterInfo, Guids);
    FStaticParameterSet StaticParameters = Instance->GetStaticParameters();

    for (int32 ParameterIdx = 0; ParameterIdx < OutParameterInfo.Num(); ParameterIdx++)
    {
        const FMaterialParameterInfo &ParameterInfo = OutParameterInfo[ParameterIdx];
        const FGuid ExpressionId = Guids[ParameterIdx];
        if (ParameterInfo.Name == ParameterName)
        {
            new (StaticParameters.StaticSwitchParameters) FStaticSwitchParameter(ParameterInfo, SwitchValue, bOverride, ExpressionId);
            break;
        }
    }
    Instance->UpdateStaticPermutation(StaticParameters);
}

void UPyToolkitBPLibrary::SetMaterialInstanceComponentMaskParameter(UMaterialInstance *Instance, FName ParameterName, bool InR, bool InG, bool InB, bool InA, bool bOverride)
{
    TArray<FGuid> Guids;
    TArray<FMaterialParameterInfo> OutParameterInfo;
    Instance->GetAllStaticComponentMaskParameterInfo(OutParameterInfo, Guids);
    FStaticParameterSet StaticParameters = Instance->GetStaticParameters();

    for (int32 ParameterIdx = 0; ParameterIdx < OutParameterInfo.Num(); ParameterIdx++)
    {
        const FMaterialParameterInfo &ParameterInfo = OutParameterInfo[ParameterIdx];
        const FGuid ExpressionId = Guids[ParameterIdx];
        if (ParameterInfo.Name == ParameterName)
        {
            FStaticComponentMaskParameter *NewParameter = new (StaticParameters.EditorOnly.StaticComponentMaskParameters) FStaticComponentMaskParameter(ParameterInfo, InR, InG, InB, InA, bOverride, ExpressionId);
            break;
        }
    }
    Instance->UpdateStaticPermutation(StaticParameters);
}

void UPyToolkitBPLibrary::GetComponentMasksNames(UMaterialInterface* Material, TArray<FName>& ParameterNames)
{
    ParameterNames.Empty();
    if (Material)
    {
        TArray<FMaterialParameterInfo> MaterialInfo;
        TArray<FGuid> MaterialGuids;
        Material->GetAllStaticComponentMaskParameterInfo(MaterialInfo, MaterialGuids);

        for (const FMaterialParameterInfo& Info : MaterialInfo)
        {
            ParameterNames.Add(Info.Name);
        }
    }
}

bool UPyToolkitBPLibrary::GetStaticComponentMaskParameterValue(UMaterialInstance* MaterialInstance, FName ParameterName, EMaterialParameterAssociation Association, bool& R, bool& G, bool& B, bool& A, FGuid& OutExpressionGuid, bool bOveriddenOnly)
{
    bool bResult = false;
    int Index = -1;
    if (Association == LayerParameter)
    {
        Index = 0;
    }

    FHashedMaterialParameterInfo MaterialParameterInfo(ParameterName, Association, Index);
    /*UE_LOG(LogTemp, Warning, TEXT("Index value is: %d"), Index);
    UE_LOG(LogTemp, Warning, TEXT("ParameterName is: %s"), *ParameterName.ToString());
    UE_LOG(LogTemp, Warning, TEXT("Association: %i"), Association);*/
    bResult = MaterialInstance->GetStaticComponentMaskParameterValue(MaterialParameterInfo, R, G, B, A, OutExpressionGuid, bOveriddenOnly);
    return bResult;
}

void UPyToolkitBPLibrary::ForceRecompileMaterialInstance(UMaterialInstance* MaterialInstance)
{
    TArray<FGuid> Guids;
    TArray<FMaterialParameterInfo> OutParameterInfo;
    MaterialInstance->GetAllTextureParameterInfo(OutParameterInfo, Guids);
    FStaticParameterSet StaticParameters = MaterialInstance->GetStaticParameters();
    MaterialInstance->UpdateStaticPermutation(StaticParameters);
}

bool UPyToolkitBPLibrary::IsStaticSwitchOverridden(UMaterialInstance* Instance, FName ParameterName)
{
    if (!Instance || ParameterName.IsNone()) return false;

    UMaterialInstanceConstant* MIC = Cast<UMaterialInstanceConstant>(Instance);
    if (!MIC) return false;

    const bool CurrValue = UMaterialEditingLibrary::GetMaterialInstanceStaticSwitchParameterValue(
        MIC, ParameterName); // Association defaults to GlobalParameter

    const bool DefaultValue = UMaterialEditingLibrary::GetMaterialDefaultStaticSwitchParameterValue(
        Instance->GetMaterial(), ParameterName);

    return CurrValue != DefaultValue;
}

void UPyToolkitBPLibrary::GetOverriddenStaticSwitches(UMaterialInstance* Instance, TArray<FName>& OutOverridden)
{
    OutOverridden.Reset();
    if (!Instance) return;

    TArray<FName> Names;
    UMaterialEditingLibrary::GetStaticSwitchParameterNames(Instance, Names);

    UMaterialInstanceConstant* MIC = Cast<UMaterialInstanceConstant>(Instance);
    if (!MIC) return;

    for (const FName& N : Names)
    {
        const bool CurrValue = UMaterialEditingLibrary::GetMaterialInstanceStaticSwitchParameterValue(MIC, N);
        const bool DefaultValue = UMaterialEditingLibrary::GetMaterialDefaultStaticSwitchParameterValue(Instance->GetMaterial(), N);
        if (CurrValue != DefaultValue)
        {
            OutOverridden.Add(N);
        }
    }
}

// Resets by setting the instance value to the base Material default (no direct API to clear only the checkbox).
bool UPyToolkitBPLibrary::ResetStaticSwitchToDefault(UMaterialInstance* Instance, FName ParameterName, bool bMarkDirtyAsset)
{
    if (!Instance || ParameterName.IsNone()) return false;

    UMaterialInstanceConstant* MIC = Cast<UMaterialInstanceConstant>(Instance);
    if (!MIC) return false;

    const bool DefaultValue = UMaterialEditingLibrary::GetMaterialDefaultStaticSwitchParameterValue(
        Instance->GetMaterial(), ParameterName);

    // Write default + update immediately
    const bool bOk = UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(
        MIC, ParameterName, DefaultValue, EMaterialParameterAssociation::GlobalParameter, /*bUpdate*/ true);

    if (!bOk) return false;

    if (bMarkDirtyAsset) { Instance->MarkPackageDirty(); }
    else if (UPackage* Pkg = Instance->GetOutermost()) { Pkg->SetDirtyFlag(false); }
    return true;
}

int32 UPyToolkitBPLibrary::ResetAllOverriddenStaticSwitches(UMaterialInstance* Instance, bool bMarkDirtyAsset)
{
    int32 NumReset = 0;
    if (!Instance) return 0;

    TArray<FName> Names;
    UMaterialEditingLibrary::GetStaticSwitchParameterNames(Instance, Names);

    UMaterialInstanceConstant* MIC = Cast<UMaterialInstanceConstant>(Instance);
    if (!MIC) return 0;

    // Batch: set all to default with bUpdate=false, then one final update
    for (const FName& N : Names)
    {
        const bool CurrValue = UMaterialEditingLibrary::GetMaterialInstanceStaticSwitchParameterValue(MIC, N);
        const bool DefaultValue = UMaterialEditingLibrary::GetMaterialDefaultStaticSwitchParameterValue(Instance->GetMaterial(), N);

        if (CurrValue != DefaultValue)
        {
            const bool bOk = UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(
                MIC, N, DefaultValue, EMaterialParameterAssociation::GlobalParameter, /*bUpdate*/ false);
            if (bOk) { ++NumReset; }
        }
    }

    if (NumReset > 0)
    {
        // Force a single update/compile after the batch
        UMaterialEditingLibrary::UpdateMaterialInstance(MIC);

        if (bMarkDirtyAsset) { Instance->MarkPackageDirty(); }
        else if (UPackage* Pkg = Instance->GetOutermost()) { Pkg->SetDirtyFlag(false); }
    }
    return NumReset;
}


#pragma endregion


#pragma region Texture

UTextureCube* UPyToolkitBPLibrary::RenderTargetCubeCreateStaticTextureCube(UTextureRenderTargetCube* RenderTarget, FString InName)
{
    FString Name;
    FString PackageName;
    IAssetTools& AssetTools = FModuleManager::Get().LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();

    // Use asset name only if directories are specified, otherwise full path
    if (!InName.Contains(TEXT("/")))
    {
        FString AssetName = RenderTarget->GetOutermost()->GetName();
        const FString SanitizedBasePackageName = UPackageTools::SanitizePackageName(AssetName);
        const FString PackagePath = FPackageName::GetLongPackagePath(SanitizedBasePackageName) + TEXT("/");
        AssetTools.CreateUniqueAssetName(PackagePath, InName, PackageName, Name);
    }
    else
    {
        InName.RemoveFromStart(TEXT("/"));
        InName.RemoveFromStart(TEXT("Content/"));
        InName.StartsWith(TEXT("Game/")) == true ? InName.InsertAt(0, TEXT("/")) : InName.InsertAt(0, TEXT("/Game/"));
        AssetTools.CreateUniqueAssetName(InName, TEXT(""), PackageName, Name);
    }

    UTextureCube* NewTex = nullptr;

    // create a static 2d texture
    NewTex = RenderTarget->ConstructTextureCube(CreatePackage(*PackageName), Name, RenderTarget->GetMaskedFlags() | RF_Public | RF_Standalone);
    if (NewTex != nullptr)
    {
        // package needs saving
        NewTex->MarkPackageDirty();

        // Notify the asset registry
        FAssetRegistryModule::AssetCreated(NewTex);
    }
    return NewTex;
}

bool UPyToolkitBPLibrary::TextureHasAlphaChannel(UTexture2D* Texture2D)
{
    bool bResult = false;
    bResult = Texture2D->HasAlphaChannel();
    return bResult;
}

void UPyToolkitBPLibrary::GetTextureSize(UTexture2D* Texture2D, int32& X, int32& Y)
{
    X = Texture2D->GetSizeX();
    Y = Texture2D->GetSizeY();
}

void UPyToolkitBPLibrary::AddTexture2DArray(UTexture2DArray* Texture2DArray, TArray<UTexture2D*> Textures)
{
    if (!ensure(Texture2DArray))
    {
        UE_LOG(LogTemp, Error, TEXT("Texture2DArray is invalid"));
		return;
    }
    if (Textures.Num() > 0)
    {
        Texture2DArray->Modify();
        for (int32 TextureIndex = 0; TextureIndex < Textures.Num(); ++TextureIndex) 
        {
            Texture2DArray->SourceTextures.Add(Textures[TextureIndex]);
        }

        // Create the texture array resource and corresponding rhi resource.
        Texture2DArray->UpdateSourceFromSourceTextures();
    }
}

#pragma endregion


#pragma region Msic

// https://forums.unrealengine.com/development-discussion/python-scripting/1703959-how-to-add-component-to-existing-actor-in-level-with-python-blueprint
// You pass to it class of component, otherwise it creates StaticMeshComponent
UActorComponent *UPyToolkitBPLibrary::AddComponent(AActor *a, USceneComponent *future_parent, FName name, UClass *NewComponentClass)
{

    UActorComponent *retComponent = nullptr;
    if (NewComponentClass)
    {
        UActorComponent *NewComponent = NewObject<UActorComponent>(a, NewComponentClass, name);
        FTransform CmpTransform; // = dup_source->GetComponentToWorld();
        // NewComponent->AttachToComponent(sc, FAttachmentTransformRules::KeepWorldTransform);
        //  Do Scene Attachment if this new Comnponent is a USceneComponent
        if (USceneComponent *NewSceneComponent = Cast<USceneComponent>(NewComponent))
        {
            if (future_parent != 0)
                NewSceneComponent->AttachToComponent(future_parent, FAttachmentTransformRules::KeepWorldTransform);
            else
                NewSceneComponent->AttachToComponent(a->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

            NewSceneComponent->SetComponentToWorld(CmpTransform);
        }
        a->AddInstanceComponent(NewComponent);
        NewComponent->OnComponentCreated();
        NewComponent->RegisterComponent();

        a->RerunConstructionScripts();
        retComponent = NewComponent;
    }

    return retComponent;
}



TArray<uint8> UPyToolkitBPLibrary::GetThumbnail(UObject *MeshObject, int32 _imageRes)
{
    // NOTE https://blog.csdn.net/zhangxiaofan666/article/details/97643308
    // int32 _imageRes = 128;
    FObjectThumbnail _objectThumnail;
    ThumbnailTools::RenderThumbnail(MeshObject, _imageRes, _imageRes, ThumbnailTools::EThumbnailTextureFlushMode::AlwaysFlush, NULL, &_objectThumnail);
    return _objectThumnail.GetUncompressedImageData();
}

void UPyToolkitBPLibrary::RunFunction(UObject *CDO, UFunction *Function)
{
    // We dont run this on the CDO, as bad things could occur!
    UObject *TempObject = NewObject<UObject>(GetTransientPackage(), Cast<UObject>(CDO)->GetClass());
    TempObject->AddToRoot(); // Some Blutility actions might run GC so the TempObject needs to be rooted to avoid getting destroyed

    FScopedTransaction Transaction(NSLOCTEXT("UnrealEd", "BlutilityAction", "Blutility Action"));
    FEditorScriptExecutionGuard ScriptGuard;
    TempObject->ProcessEvent(Function, nullptr);
    TempObject->RemoveFromRoot();
}

#pragma endregion
#pragma region SlowTask


#pragma endregion

#pragma region Notification

void UPyToolkitBPLibrary::ShowNotification(FString NotificationText, float ExpireDuration, bool bUseLargeFont, EState CompletionState)
{
    FNotificationInfo Info(FText::FromString(NotificationText));

	Info.ExpireDuration = ExpireDuration;
	Info.bUseLargeFont = bUseLargeFont;
	Info.bUseThrobber = true;
    
    SNotificationItem::ECompletionState State = SNotificationItem::CS_None;

    if (CompletionState == EState::Success)
    {
		State = SNotificationItem::CS_Success;
    }
    else if (CompletionState == EState::Pending)
    {
        State = SNotificationItem::CS_Pending;
    }
    else if (CompletionState == EState::Fail)
    {
        State = SNotificationItem::CS_Fail;
    }
    
    FSlateNotificationManager::Get().AddNotification(Info)->SetCompletionState(State);

}

#pragma endregion

#pragma region MessageLog

void UPyToolkitBPLibrary::RegisterWidgetMessageLog()
{
    FMessageLogModule& MessageLogModule = FModuleManager::LoadModuleChecked<FMessageLogModule>("MessageLog");
    if (!MessageLogModule.IsRegisteredLogListing("WidgetLog"))
	{
		FMessageLogInitializationOptions InitOptions;
        InitOptions.bShowPages = true;
        InitOptions.bAllowClear = true;
        InitOptions.bShowFilters = true;
        MessageLogModule.RegisterLogListing("WidgetLog", NSLOCTEXT("WidgetLog", "WidgetLogLabel", "Widget Log"), InitOptions);
	}
}

void UPyToolkitBPLibrary::ResetWidgetMessageLog(FString PageName)
{
    FMessageLog MessageLog("WidgetLog");
    MessageLog.NewPage(FText::FromString(PageName));
    MessageLog.SetCurrentPage(FText::FromString(PageName));
}

void UPyToolkitBPLibrary::OpenWidgetMessageLog()
{
    FMessageLog MessageLog("WidgetLog");
    MessageLog.Open(EMessageSeverity::Info, true);
}

EMessageSeverity::Type GetSeverity(ESeverity Severity)
{
    switch (Severity) 
	{
	case ESeverity::Error:
		return EMessageSeverity::Error;
	case ESeverity::PerformanceWarning:
		return EMessageSeverity::PerformanceWarning;
	case ESeverity::Warning:
		return EMessageSeverity::Warning;
	case ESeverity::Info:
		return EMessageSeverity::Info;
	};
	ensureMsgf(false, TEXT("Unknown type of ESeverity!"));
	return EMessageSeverity::Info;
}

void UPyToolkitBPLibrary::AddSimpleMessageToWidgetMessageLog(FString Message, ESeverity Severity, bool ShowNotification, FString NotificationText)
{
    FMessageLog MessageLog("WidgetLog");
    EMessageSeverity::Type MsgSeverity = GetSeverity(Severity);
    MessageLog.Message(MsgSeverity, FText::FromString(Message));
    MessageLog.SuppressLoggingToOutputLog(true);
}


void UPyToolkitBPLibrary::ShowNotificationWidgetMessageLog(FString Message, ESeverity Severity, bool ForceNotify)
{
    FMessageLog MessageLog("WidgetLog");
    EMessageSeverity::Type MsgSeverity = GetSeverity(Severity);
    MessageLog.Notify(FText::FromString(Message), MsgSeverity, ForceNotify);
}

void UPyToolkitBPLibrary::LogActorMaterialWarning(AActor* Actor, UMaterialInterface* Material, const FString& AdditionalMessage)
{
    if (Actor && Material)
    {
        // Create a message log
        FMessageLog MessageLog("WidgetLog");

        // Construct the warning message
        MessageLog.Warning()
            ->AddToken(FUObjectToken::Create(Actor)) // Add the actor token
            ->AddToken(FTextToken::Create(FText::FromString("has material"))) // Add static text
            ->AddToken(FUObjectToken::Create(Material)) // Add the material token
            ->AddToken(FTextToken::Create(FText::FromString(AdditionalMessage))); // Add additional message token

        // Optionally, open the log
        MessageLog.Open(EMessageSeverity::Warning, true);
    }
}

#pragma endregion
