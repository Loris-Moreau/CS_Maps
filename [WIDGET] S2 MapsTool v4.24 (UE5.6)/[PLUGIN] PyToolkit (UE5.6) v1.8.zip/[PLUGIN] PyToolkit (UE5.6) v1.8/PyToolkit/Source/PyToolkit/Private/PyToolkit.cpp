// Copyright Epic Games, Inc. All Rights Reserved.

#include "PyToolkit.h"
#include "Modules/ModuleManager.h"
#include "PropertyEditorModule.h"
#include "AnyMetaCustomization.h"

#define LOCTEXT_NAMESPACE "FPyToolkitModule"

void FPyToolkitModule::StartupModule()
{
    FPropertyEditorModule& PM = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");

    auto Register = [&PM](const TCHAR* ClassName)
    {
        PM.RegisterCustomClassLayout(
            FName(ClassName),
            FOnGetDetailCustomizationInstance::CreateStatic(&FAnyMetaCustomization::MakeInstance));
    };

    Register(TEXT("Object"));
    Register(TEXT("Actor"));
    Register(TEXT("ActorComponent"));
    Register(TEXT("SceneComponent"));
    Register(TEXT("UserWidget"));
    Register(TEXT("DataAsset"));

    PM.NotifyCustomizationModuleChanged();
}

void FPyToolkitModule::ShutdownModule()
{
    if (FModuleManager::Get().IsModuleLoaded("PropertyEditor"))
    {
        FPropertyEditorModule& PM = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");

        auto Unreg = [&PM](const TCHAR* ClassName)
        {
            PM.UnregisterCustomClassLayout(FName(ClassName));
        };

        Unreg(TEXT("Object"));
        Unreg(TEXT("Actor"));
        Unreg(TEXT("ActorComponent"));
        Unreg(TEXT("SceneComponent"));
        Unreg(TEXT("UserWidget"));
        Unreg(TEXT("DataAsset"));

        PM.NotifyCustomizationModuleChanged();
    }
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FPyToolkitModule, PyToolkit)