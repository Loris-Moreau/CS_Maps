#include "AnyMetaSettings.h"

UAnyMetaSettings* UAnyMetaSettings::Get()
{
    return GetMutableDefault<UAnyMetaSettings>();
}

bool UAnyMetaSettings::Get(const UObject* Obj, FName Prop, FAnyMetaForProperty& Out) const
{
    if (!Obj) return false;
    const FSoftObjectPath Key(Obj);
    if (const FAnyMetaForObject* O = Overlays.Find(Key))
    {
        if (const FAnyMetaForProperty* P = O->ByProperty.Find(Prop))
        {
            Out = *P;
            return true;
        }
    }
    return false;
}

void UAnyMetaSettings::Put(const UObject* Obj, FName Prop, const FAnyMetaForProperty& In)
{
    if (!Obj) return;
    const FSoftObjectPath Key(Obj);
    Overlays.FindOrAdd(Key).ByProperty.FindOrAdd(Prop) = In;
    Save();
}

void UAnyMetaSettings::Save()
{
    SaveConfig();
}
