#include "Widgets/Input/STextComboBox.h"

#include "AnyMetaCustomization.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailPropertyRow.h"
#include "PropertyHandle.h"
#include "AnyMetaSettings.h"
#include "EditConditionEvaluator.h"

#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SGridPanel.h"

#include "UObject/UnrealType.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Engine/Blueprint.h"
#include "Engine/BlueprintGeneratedClass.h"

#include "Styling/AppStyle.h"
#include "Brushes/SlateRoundedBoxBrush.h"


#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Misc/Paths.h"

static const FSlateRoundedBoxBrush* AnyMeta_GetChipBrush()
{
    static FSlateRoundedBoxBrush Brush(FLinearColor(0.10f, 0.55f, 0.10f, 0.95f), 6.f);
    return &Brush;
}

static void ForEachProperty(UObject* Obj, TFunctionRef<void(FProperty*)> Fn)
{
    if (!Obj) return;
    for (TFieldIterator<FProperty> It(Obj->GetClass(), EFieldIterationFlags::IncludeSuper); It; ++It)
    {
        Fn(*It);
    }
}

static bool GatherBPVarMeta(UObject* Obj, FName PropName, TMap<FName,FString>& Out)
{
    UClass* Cls = Obj ? Obj->GetClass() : nullptr;
    if (UBlueprintGeneratedClass* BGC = Cast<UBlueprintGeneratedClass>(Cls))
    {
        if (UBlueprint* BP = Cast<UBlueprint>(BGC->ClassGeneratedBy))
        {
            for (FBPVariableDescription& Desc : BP->NewVariables)
            {
                if (Desc.VarName == PropName)
                {
                    for (const FBPVariableMetaDataEntry& Entry : Desc.MetaDataArray)
                    {
                        Out.Add(Entry.DataKey, Entry.DataValue);
                    }
                    return true;
                }
            }
        }
    }
    return false;
}

static TSharedRef<SWidget> MakePathPicker(TSharedRef<IPropertyHandle> PH, bool bDirectory, const TMap<FName,FString>& EffectiveMeta)
{
    TSharedPtr<IPropertyHandle> PathHandle = PH->GetChildHandle(bDirectory ? TEXT("Path") : TEXT("FilePath"));
    if (!PathHandle.IsValid() || !PathHandle->IsValidHandle())
    {
        PathHandle = PH->GetChildHandle(TEXT("Path"));
    }

    auto GetText = [PathHandle]() -> FText
    {
        FString V; if (PathHandle.IsValid()) PathHandle->GetValue(V);
        return FText::FromString(V);
    };

    auto SetText = [PathHandle](const FText& T)
    {
        if (PathHandle.IsValid())
        {
            FString S = T.ToString();
            PathHandle->SetValue(S);
        }
    };

    auto OnBrowse = [PathHandle, bDirectory, EffectiveMeta]()
    {
        IDesktopPlatform* Desktop = FDesktopPlatformModule::Get();
        if (!Desktop) return;

        void* ParentWindowHandle = nullptr;
        FString Cur; if (PathHandle.IsValid()) PathHandle->GetValue(Cur);
        FString StartDir = Cur.IsEmpty() ? FPaths::ProjectDir() : FPaths::GetPath(Cur);

        if (bDirectory)
        {
            FString OutDir;
            if (Desktop->OpenDirectoryDialog(ParentWindowHandle, TEXT("Choose Directory"), StartDir, OutDir))
            {
                PathHandle->SetValue(OutDir);
            }
        }
        else
        {
            FString Filter = TEXT("All Files (*.*)|*.*");
            if (const FString* MetaFilter = EffectiveMeta.Find(TEXT("FilePathFilter")))
            {
                const FString& In = *MetaFilter;
                if (In.Contains(TEXT("|"))) Filter = In;
                else Filter = FString::Printf(TEXT("Files (%s)|%s"), *In, *In);
            }

            TArray<FString> OutFiles;
            if (Desktop->OpenFileDialog(ParentWindowHandle, TEXT("Choose File"), StartDir, TEXT(""), Filter, EFileDialogFlags::None, OutFiles))
            {
                if (OutFiles.Num() > 0) PathHandle->SetValue(OutFiles[0]);
            }
        }
    };

    return SNew(SHorizontalBox)
        +SHorizontalBox::Slot().FillWidth(1.f)
        [
            SNew(SEditableTextBox)
            .Text_Lambda(GetText)
            .OnTextCommitted_Lambda([SetText](const FText& T, ETextCommit::Type){ SetText(T); })
        ]
        +SHorizontalBox::Slot().AutoWidth().Padding(4,0)
        [
            SNew(SButton)
            .Text(FText::FromString(TEXT("...")))
            .OnClicked_Lambda([OnBrowse](){ OnBrowse(); return FReply::Handled(); })
        ];
}

static TSharedRef<SWidget> MakeValueWidget(FProperty* P, TSharedRef<IPropertyHandle> PH, const TMap<FName,FString>& EffectiveMeta)
{
    if (const FStructProperty* SP = CastField<FStructProperty>(P))
    {
        const FName SN = SP->Struct ? SP->Struct->GetFName() : NAME_None;
        if (SN == FName("DirectoryPath")) return MakePathPicker(PH, true, EffectiveMeta);
        if (SN == FName("FilePath")) return MakePathPicker(PH, false, EffectiveMeta);
    }
    return PH->CreatePropertyValueWidget();
}

TSharedRef<IDetailCustomization> FAnyMetaCustomization::MakeInstance()
{
    return MakeShareable(new FAnyMetaCustomization());
}

void FAnyMetaCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
    
	BuildQuickEditConditions(DetailBuilder);
TArray<TWeakObjectPtr<UObject>> Objects;
    DetailBuilder.GetObjectsBeingCustomized(Objects);

    ApplyOverlays(DetailBuilder, Objects);
    BuildEditorUI(DetailBuilder, Objects);
}

void FAnyMetaCustomization::ApplyOverlays(IDetailLayoutBuilder& DetailBuilder, const TArray<TWeakObjectPtr<UObject>>& Objects)
{
    if (Objects.Num() == 0) return;
    UAnyMetaSettings* Settings = UAnyMetaSettings::Get();
    if (!Settings) return;

    for (const TWeakObjectPtr<UObject>& WObj : Objects)
    {
        UObject* Obj = WObj.Get();
        if (!Obj) continue;

        const bool bIsCDO = Obj->HasAnyFlags(RF_ClassDefaultObject);

        ForEachProperty(Obj, [&](FProperty* P)
        {
            const FName PropName = P->GetFName();

            FAnyMetaForProperty Overlay;
            Settings->Get(Obj, PropName, Overlay);

            TMap<FName,FString> Merged = Overlay.Meta;
            TMap<FName,FString> BPMap;
            GatherBPVarMeta(Obj, PropName, BPMap);
            for (const auto& KV : BPMap)
            {
                if (!Merged.Contains(KV.Key))
                {
                    Merged.Add(KV.Key, KV.Value);
                }
            }

            TSharedRef<IPropertyHandle> PH = DetailBuilder.GetProperty(PropName, Obj->GetClass());
            if (!PH->IsValidHandle()) return;

            for (const auto& Pair : Overlay.Meta)
            {
                PH->SetInstanceMetaData(Pair.Key, Pair.Value);
            }

            IDetailPropertyRow* Row = DetailBuilder.EditDefaultProperty(PH);
            if (!Row) return;

            // EditCondition
            {
                FString EC = Overlay.EditCondition;
                if (EC.IsEmpty() && P && P->HasMetaData(TEXT("EditCondition")))
                {
                    EC = P->GetMetaData(TEXT("EditCondition"));
                }
                if (!EC.IsEmpty())
                {
                    TWeakObjectPtr<const UObject> Tgt = Obj; const FString Expr = EC;
                    Row->IsEnabled(TAttribute<bool>::Create(TAttribute<bool>::FGetter::CreateLambda([Tgt, Expr]() { return FEditConditionEvaluator::Evaluate(Tgt.Get(), Expr); })));
                }
            }

            if (bIsCDO)
            {
                // Build the list of existing metas
                TSharedRef<SVerticalBox> MetaList = SNew(SVerticalBox);

                for (const auto& KV : Merged)
                {
                    const FName K = KV.Key;
                    const FString V = KV.Value;

                    MetaList->AddSlot()
                    .AutoHeight()
                    .Padding(0,1,0,1)
                    [
                        SNew(SHorizontalBox)
                        +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,8,0)
                        [
                            SNew(SBorder)
                            .Padding(FMargin(8,2))
                            .BorderImage(AnyMeta_GetChipBrush())
                            [
                                SNew(STextBlock).Text(FText::FromName(K)).ColorAndOpacity(FLinearColor::White)
                            ]
                        ]
                        +SHorizontalBox::Slot().FillWidth(1.f)
                        [
                            SNew(SEditableTextBox)
                            .Text(FText::FromString(V))
                            .OnTextCommitted_Lambda([Obj, PropName, K, &DetailBuilder, PH](const FText& NewText, ETextCommit::Type)
                            {
                                FAnyMetaForProperty Cur; UAnyMetaSettings* S = UAnyMetaSettings::Get();
                                S->Get(Obj, PropName, Cur);
                                Cur.Meta.FindOrAdd(K) = NewText.ToString().TrimStartAndEnd();
                                S->Put(Obj, PropName, Cur);
                                PH->SetInstanceMetaData(K, Cur.Meta[K]);
                                ((class FAnyMetaCustomization*)nullptr)->WriteToBlueprintIfPossible(Obj, PropName, Cur.Meta, Cur.EditCondition);
                            })
                        ]
                        +SHorizontalBox::Slot().AutoWidth().Padding(4,0)
                        [
                            SNew(SButton)
                            .Text(FText::FromString(TEXT("—")))
                            .ToolTipText(FText::FromString(TEXT("Remove")))
                            .OnClicked_Lambda([Obj, PropName, K, &DetailBuilder, PH]()
                            {
                                FAnyMetaForProperty Cur; UAnyMetaSettings* S = UAnyMetaSettings::Get();
                                S->Get(Obj, PropName, Cur);
                                Cur.Meta.Remove(K);
                                S->Put(Obj, PropName, Cur);
                                PH->SetInstanceMetaData(K, TEXT(""));

                                if (UBlueprintGeneratedClass* BGC = Cast<UBlueprintGeneratedClass>(Obj->GetClass()))
                                {
                                    if (UBlueprint* BP = Cast<UBlueprint>(BGC->ClassGeneratedBy))
                                    {
                                        for (FBPVariableDescription& Desc : BP->NewVariables)
                                        {
                                            if (Desc.VarName == PropName)
                                            {
                                                Desc.RemoveMetaData(K);
                                                FBlueprintEditorUtils::MarkBlueprintAsModified(BP);
                                                FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BP);
                                                break;
                                            }
                                        }
                                    }
                                }
                                DetailBuilder.ForceRefreshDetails();
                                return FReply::Handled();
                            })
                        ]
                    ];
                }

                // Add row
                TSharedPtr<SEditableTextBox> NewKey;
                TSharedPtr<SEditableTextBox> NewVal;
                MetaList->AddSlot()
                .AutoHeight()
                .Padding(0,5,0,3)
                [
                    SNew(SHorizontalBox)
                    +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,8,0)
                    [
                        SNew(STextBlock).Text(FText::FromString(TEXT("Add")))
                    ]
                    +SHorizontalBox::Slot().FillWidth(0.5f)
                    [
                        SAssignNew(NewKey, SEditableTextBox).HintText(FText::FromString(TEXT("Key (e.g. Units/UIMin/ContentDir)")))
                    ]
                    +SHorizontalBox::Slot().FillWidth(0.5f)
                    [
                        SAssignNew(NewVal, SEditableTextBox).HintText(FText::FromString(TEXT("Value (blank for flag)")))
                    ]
                    +SHorizontalBox::Slot().AutoWidth().Padding(4,0)
                    [
                        SNew(SButton)
                        .Text(FText::FromString(TEXT("Apply")))
                        .OnClicked_Lambda([Obj, PropName, &DetailBuilder, PH, NewKey, NewVal]()
                        {
                            if (!Obj) return FReply::Handled();
                            const FString K = NewKey.IsValid() ? NewKey->GetText().ToString().TrimStartAndEnd() : TEXT("");
                            const FString V = NewVal.IsValid() ? NewVal->GetText().ToString().TrimStartAndEnd() : TEXT("");
                            if (K.IsEmpty()) return FReply::Handled();

                            FAnyMetaForProperty Cur; UAnyMetaSettings* S = UAnyMetaSettings::Get();
                            S->Get(Obj, PropName, Cur);
                            Cur.Meta.FindOrAdd(FName(*K)) = V;
                            S->Put(Obj, PropName, Cur);

                            PH->SetInstanceMetaData(FName(*K), V);
                            ((class FAnyMetaCustomization*)nullptr)->WriteToBlueprintIfPossible(Obj, PropName, Cur.Meta, Cur.EditCondition);

                            DetailBuilder.ForceRefreshDetails();
                            return FReply::Handled();
                        })
                    ]
                ];

                // Build value widget first (restores FFilePath/FDirectoryPath pickers)
                TSharedRef<SWidget> ValueWidget = MakeValueWidget(P, PH, Merged);

                // Attach to row
                Row->CustomWidget()
                .NameContent()[ PH->CreatePropertyNameWidget() ]
                .ValueContent().MinDesiredWidth(400).MaxDesiredWidth(4096)
                [
                    SNew(SBox).MinDesiredWidth(700).HAlign(HAlign_Fill)
                    [
                        SNew(SVerticalBox)
                        +SVerticalBox::Slot().AutoHeight()
                        [
                            SNew(SBox).HAlign(HAlign_Fill)
                            [
                                ValueWidget
                            ]
                        ]
                        +SVerticalBox::Slot().AutoHeight().Padding(0,10,0,5)
                        [
                            SNew(SExpandableArea)
                            .InitiallyCollapsed(true)
                            .AreaTitle(FText::FromString(TEXT("Meta")))
                            .BorderBackgroundColor(FLinearColor(0.10f, 0.55f, 0.10f, 0.65f))
                            .BodyContent()
                            [
                                SNew(SBox).Padding(FMargin(10,0,0,0))
                                [
                                    MetaList
                                ]
                            ]
                        ]
                    ]
                ];
            }
        });
    }
}

void FAnyMetaCustomization::WriteToBlueprintIfPossible(UObject* Obj, FName PropName, const TMap<FName,FString>& Meta, const FString& EditCond)
{
    if (!Obj) return;

    UClass* Cls = Obj->GetClass();
    if (UBlueprintGeneratedClass* BGC = Cast<UBlueprintGeneratedClass>(Cls))
    {
        if (UBlueprint* BP = Cast<UBlueprint>(BGC->ClassGeneratedBy))
        {
            for (FBPVariableDescription& Desc : BP->NewVariables)
            {
                if (Desc.VarName == PropName)
                {
                    for (const auto& KV : Meta) { Desc.SetMetaData(KV.Key, KV.Value); }
                    if (!EditCond.IsEmpty()) { Desc.SetMetaData(TEXT("EditCondition"), EditCond); }

                    FBlueprintEditorUtils::MarkBlueprintAsModified(BP);
                    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BP);
                    break;
                }
            }
        }
    }
}

void FAnyMetaCustomization::BuildEditorUI(IDetailLayoutBuilder& DetailBuilder, const TArray<TWeakObjectPtr<UObject>>& Objects)
{
    // No global Class Defaults panel per request.
}

void FAnyMetaCustomization::BuildQuickEditConditions(IDetailLayoutBuilder& DetailBuilder)
{
    IDetailCategoryBuilder& Cat = DetailBuilder.EditCategory(
        TEXT("QuickEditConditions"),
        FText::GetEmpty(),
        ECategoryPriority::Important);

    TSharedPtr<SEditableTextBox> ChildBox;
    TSharedPtr<SEditableTextBox> ParentBox;

        // Build options from current selection's Blueprint variables (no filtering)
    VarOptions = MakeShared<TArray<TSharedPtr<FString>>>();
    {
        TArray<TWeakObjectPtr<UObject>> Objects;
        DetailBuilder.GetObjectsBeingCustomized(Objects);
        for (const TWeakObjectPtr<UObject>& WeakObj : Objects)
        {
            if (UObject* Obj = WeakObj.Get())
            {
                UBlueprint* BP = nullptr;
                if (UBlueprintGeneratedClass* BPGC = Cast<UBlueprintGeneratedClass>(Obj->GetClass()))
                {
                    BP = Cast<UBlueprint>(BPGC->ClassGeneratedBy);
                }
                else { BP = Cast<UBlueprint>(Obj); }
                if (BP)
                {
                    for (const FBPVariableDescription& Var : BP->NewVariables)
                    {
                        VarOptions->Add(MakeShared<FString>(Var.VarName.ToString()));
                    }
                    break; // use the first BP we found
                }
            }
        }
    }

    Cat.AddCustomRow(FText::FromString(TEXT("QuickEditConditions")))
    .WholeRowContent()
    [
        SNew(SGridPanel)

        // Child label
        + SGridPanel::Slot(0,0).VAlign(VAlign_Center).Padding(0.f,0.f,6.f,0.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("Child Variable")))
            .ToolTipText(FText::FromString(TEXT("Variable that will receive the EditCondition metadata.")))
        ]

        // Child dropdown
        + SGridPanel::Slot(1,0).VAlign(VAlign_Center).Padding(0.f,0.f,12.f,0.f)
        [
            SAssignNew(ChildCombo, STextComboBox)
            .OptionsSource(VarOptions.Get())
            .ToolTipText(FText::FromString(TEXT("Pick any variable name to add an EditCondition to.")))
        ]

        // Parent label
        + SGridPanel::Slot(2,0).VAlign(VAlign_Center).Padding(0.f,0.f,6.f,0.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("Parent (EditCondition)")))
            .ToolTipText(FText::FromString(TEXT("Name of the controlling variable/expression for the EditCondition.")))
        ]

        // Parent dropdown
        + SGridPanel::Slot(3,0).VAlign(VAlign_Center).Padding(0.f,0.f,12.f,0.f)
        [
            SAssignNew(ParentCombo, STextComboBox)
            .OptionsSource(VarOptions.Get())
            .ToolTipText(FText::FromString(TEXT("Pick any variable (no filtering applied). You can still type expressions later if needed.")))
        ]

        // Apply
        + SGridPanel::Slot(4,0).HAlign(HAlign_Right).VAlign(VAlign_Center)
        [
            SNew(SButton)
            .Text(FText::FromString(TEXT("Apply")))
            .OnClicked_Lambda([this, &DetailBuilder]()
            {
                FString Child = ChildCombo.IsValid() && ChildCombo->GetSelectedItem().IsValid() ? *ChildCombo->GetSelectedItem() : FString();
                FString Parent = ParentCombo.IsValid() && ParentCombo->GetSelectedItem().IsValid() ? *ParentCombo->GetSelectedItem() : FString();

                if (Child.IsEmpty() || Parent.IsEmpty())
                {
                    return FReply::Handled();
                }

                TArray<TWeakObjectPtr<UObject>> Objects;
                DetailBuilder.GetObjectsBeingCustomized(Objects);

                for (const TWeakObjectPtr<UObject>& WeakObj : Objects)
                {
                    if (UObject* Obj = WeakObj.Get())
                    {
                        UBlueprint* BP = nullptr;
                        if (UBlueprintGeneratedClass* BPGC = Cast<UBlueprintGeneratedClass>(Obj->GetClass()))
                        {
                            BP = Cast<UBlueprint>(BPGC->ClassGeneratedBy);
                        }
                        else
                        {
                            BP = Cast<UBlueprint>(Obj);
                        }

                        if (!BP) { continue; }

                        for (FBPVariableDescription& Var : BP->NewVariables)
                        {
                            if (Var.VarName == FName(*Child))
                            {
                                FBlueprintEditorUtils::SetBlueprintVariableMetaData(
                                    BP, Var.VarName, /*InLocalVarScope*/ nullptr,
                                    FName(TEXT("EditCondition")),
                                    Parent
                                );
                                FBlueprintEditorUtils::MarkBlueprintAsModified(BP);
                                break;
                            }
                        }
                    }
                }

                DetailBuilder.ForceRefreshDetails();
                return FReply::Handled();
            })
        ]
    ];
}
