#include "TimingBPLibrary.h"
#include "HAL/PlatformTime.h"
#include "Misc/ScopeLock.h"
#include "Logging/LogMacros.h"

DEFINE_LOG_CATEGORY(LogPyToolkit);

// ----- Timing storage -----
struct FTimingAgg
{
	double TotalSeconds = 0.0;
	int32  Count = 0;
};

struct FTimingScope
{
	FName  Name;
	double StartSeconds = 0.0;
	bool   bLog         = false;
};

static FCriticalSection               GPTK_TimingMutex;
static TArray<FTimingScope>          GPTK_ScopeStack;   // nested LIFO
static TMap<FName, FTimingAgg>       GPTK_Aggregates;

// -------- Timing API --------
void UTimingBPLibrary::StartTimedSection(FName Name, bool bLogStart)
{
	FScopeLock Lock(&GPTK_TimingMutex);

	FTimingScope Scope;
	Scope.Name         = Name;
	Scope.StartSeconds = FPlatformTime::Seconds();
	Scope.bLog         = bLogStart;

	GPTK_ScopeStack.Add(MoveTemp(Scope));

	if (bLogStart)
	{
		UE_LOG(LogPyToolkit, Display, TEXT("================= Function '%s' started."), *Name.ToString());
	}
}

float UTimingBPLibrary::FinishTimedSection(FName Name)
{
	FScopeLock Lock(&GPTK_TimingMutex);

	if (GPTK_ScopeStack.Num() == 0)
	{
		UE_LOG(LogPyToolkit, Warning, TEXT("FinishTimedSection('%s') with no open scopes."), *Name.ToString());
		return 0.f;
	}

	// Find the most recent matching Name (search from back).
	int32 MatchIndex = INDEX_NONE;
	for (int32 i = GPTK_ScopeStack.Num() - 1; i >= 0; --i)
	{
		if (GPTK_ScopeStack[i].Name == Name)
		{
			MatchIndex = i;
			break;
		}
	}

	if (MatchIndex == INDEX_NONE)
	{
		UE_LOG(LogPyToolkit, Warning, TEXT("FinishTimedSection('%s') had no matching Start."), *Name.ToString());
		return 0.f;
	}

	const double Now     = FPlatformTime::Seconds();
	const FTimingScope Scope = GPTK_ScopeStack[MatchIndex];
	const double Elapsed = Now - Scope.StartSeconds;

	// Pop this scope (preserves any outer scopes)
	GPTK_ScopeStack.RemoveAt(MatchIndex, 1, EAllowShrinking::No);

	// Aggregate
	FTimingAgg& Agg = GPTK_Aggregates.FindOrAdd(Name);
	Agg.TotalSeconds += Elapsed;
	Agg.Count        += 1;

	// If StartTimedSection requested logging, print the "finished" line
	if (Scope.bLog)
	{
		UE_LOG(LogPyToolkit, Display, TEXT("================= Function '%s' finished. Elapsed: %.4f seconds."),
			*Name.ToString(), Elapsed);
	}

	return static_cast<float>(Elapsed);
}

void UTimingBPLibrary::LogTimedStats()
{
	FScopeLock Lock(&GPTK_TimingMutex);

	if (GPTK_Aggregates.Num() == 0)
	{
		UE_LOG(LogPyToolkit, Display, TEXT("No execution stats recorded yet."));
		return;
	}

	UE_LOG(LogPyToolkit, Display, TEXT("================= Execution stats ================="));
	for (const TPair<FName, FTimingAgg>& It : GPTK_Aggregates)
	{
		const FName& Name      = It.Key;
		const FTimingAgg& Agg  = It.Value;
		UE_LOG(LogPyToolkit, Display, TEXT("Function '%s' executed %d times, total execution time: %.4f seconds."),
			*Name.ToString(), Agg.Count, Agg.TotalSeconds);
	}
}

void UTimingBPLibrary::ResetTimedStats()
{
	FScopeLock Lock(&GPTK_TimingMutex);
	GPTK_ScopeStack.Reset();
	GPTK_Aggregates.Reset();
}
