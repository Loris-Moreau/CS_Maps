#include "EditConditionEvaluator.h"
#include "UObject/UnrealType.h"

static bool GetBoolProp(const UObject* Obj, const FName Name, bool& Out)
{
    if (!Obj) return false;
    if (const FBoolProperty* BP = FindFProperty<FBoolProperty>(Obj->GetClass(), Name))
    {
        Out = BP->GetPropertyValue_InContainer(Obj);
        return true;
    }
    return false;
}

bool FEditConditionEvaluator::Evaluate(const UObject* Obj, const FString& Expr)
{
    FString S = Expr;
    S.TrimStartAndEndInline();
    if (S.IsEmpty()) return true;

    bool bNeg = false;
    if (S.StartsWith(TEXT("!")))
    {
        bNeg = true;
        S.RightChopInline(1);
        S.TrimStartInline();
    }

    bool Val = false;
    if (!GetBoolProp(Obj, FName(*S), Val))
    {
        return true;
    }
    return bNeg ? !Val : Val;
}
