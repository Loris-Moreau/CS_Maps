#include "VarByNameLite.h"

#include "UObject/Class.h"
#include "UObject/UnrealType.h"
#include "UObject/PropertyAccessUtil.h"
#include "UObject/UObjectGlobals.h"

#include "Engine/Texture.h"
#include "Engine/Texture2D.h"
#include "Engine/Texture2DArray.h"
#include "Editor.h"

/** Notify editor so bindings refresh; harmless for transient widgets. */
static void NotifyEdited(UObject* Target, FProperty* Prop, bool bNotifyEditor)
{
    if (!Target || !bNotifyEditor) return;

    Target->Modify();
    if (UPackage* Pkg = Target->GetOutermost())
    {
        Pkg->SetDirtyFlag(true);
    }

    FPropertyChangedEvent Evt(Prop, EPropertyChangeType::ValueSet);
    Target->PostEditChangeProperty(Evt);
}

static void* ValuePtr(FProperty* P, void* Container)
{
    return P ? P->ContainerPtrToValuePtr<void>(Container) : nullptr;
}

/** Generic integer setter: handles FIntProperty and integer FNumericProperty. */
static bool SetAnyInteger(UObject* Target, FName PropertyName, int64 AsInt, bool bNotify)
{
    if (!Target) return false;

    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FIntProperty* IP = CastField<FIntProperty>(Prop))
    {
        IP->SetPropertyValue_InContainer(Target, (int32)AsInt);
        NotifyEdited(Target, Prop, bNotify);
        return true;
    }

    if (FNumericProperty* NP = CastField<FNumericProperty>(Prop))
    {
        if (NP->IsInteger())
        {
            NP->SetIntPropertyValue(ValuePtr(NP, Target), AsInt);
            NotifyEdited(Target, Prop, bNotify);
            return true;
        }
    }

    return false;
}

/** Generic floating setter: supports float/double and floating FNumericProperty. */
static bool SetAnyFloat(UObject* Target, FName PropertyName, double AsDouble, bool bNotify)
{
    if (!Target) return false;

    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FFloatProperty* FP = CastField<FFloatProperty>(Prop))
    {
        FP->SetPropertyValue_InContainer(Target, (float)AsDouble);
        NotifyEdited(Target, Prop, bNotify);
        return true;
    }

#if ENGINE_MAJOR_VERSION >= 5
    if (FDoubleProperty* DP = CastField<FDoubleProperty>(Prop))
    {
        DP->SetFloatingPointPropertyValue(ValuePtr(DP, Target), AsDouble);
        NotifyEdited(Target, Prop, bNotify);
        return true;
    }
#endif

    if (FNumericProperty* NP = CastField<FNumericProperty>(Prop))
    {
        if (NP->IsFloatingPoint())
        {
            NP->SetFloatingPointPropertyValue(ValuePtr(NP, Target), AsDouble);
            NotifyEdited(Target, Prop, bNotify);
            return true;
        }
    }

    return false;
}

template<typename TProp, typename TValue>
static bool SetSimple(UObject* Target, FName PropertyName, const TValue& V, bool bNotify)
{
    if (!Target) return false;

    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (TProp* P = CastField<TProp>(Prop))
    {
        P->SetPropertyValue_InContainer(Target, V);
        NotifyEdited(Target, Prop, bNotify);
        return true;
    }
    return false;
}

static bool SetStruct(UObject* Target, FName PropertyName, UScriptStruct* S, const void* Src, SIZE_T Size, bool bNotify)
{
    if (!Target || !S) return false;

    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FStructProperty* SP = CastField<FStructProperty>(Prop))
    {
        if (SP->Struct == S)
        {
            void* Dest = SP->ContainerPtrToValuePtr<void>(Target);
            FMemory::Memcpy(Dest, Src, Size);
            NotifyEdited(Target, Prop, bNotify);
            return true;
        }
    }
    return false;
}

static bool SetObject(UObject* Target, FName PropertyName, UObject* Value, bool bNotify)
{
    if (!Target) return false;

    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FObjectProperty* OP = CastField<FObjectProperty>(Prop))
    {
        if (Value == nullptr || Value->IsA(OP->PropertyClass))
        {
            void* Dest = OP->ContainerPtrToValuePtr<void>(Target);
            OP->SetObjectPropertyValue(Dest, Value);
            NotifyEdited(Target, Prop, bNotify);
            return true;
        }
    }
    return false;
}


// ---------- Internal Get Helpers ----------

static bool GetAnyInteger(UObject* Target, FName PropertyName, int64& OutValue)
{
    if (!Target) return false;
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FIntProperty* IP = CastField<FIntProperty>(Prop))
    {
        OutValue = (int64)IP->GetPropertyValue_InContainer(Target);
        return true;
    }

    if (FNumericProperty* NP = CastField<FNumericProperty>(Prop))
    {
        if (NP->IsInteger())
        {
            OutValue = NP->GetSignedIntPropertyValue(ValuePtr(NP, Target));
            return true;
        }
    }
    return false;
}

static bool GetAnyFloat(UObject* Target, FName PropertyName, double& OutValue)
{
    if (!Target) return false;
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FFloatProperty* FP = CastField<FFloatProperty>(Prop))
    {
        OutValue = (double)FP->GetPropertyValue_InContainer(Target);
        return true;
    }

#if ENGINE_MAJOR_VERSION >= 5
    if (FDoubleProperty* DP = CastField<FDoubleProperty>(Prop))
    {
        OutValue = DP->GetFloatingPointPropertyValue(ValuePtr(DP, Target));
        return true;
    }
#endif

    if (FNumericProperty* NP = CastField<FNumericProperty>(Prop))
    {
        if (NP->IsFloatingPoint())
        {
            OutValue = NP->GetFloatingPointPropertyValue(ValuePtr(NP, Target));
            return true;
        }
    }
    return false;
}

template<typename TProp, typename TValue>
static bool GetSimple(UObject* Target, FName PropertyName, TValue& Out)
{
    if (!Target) return false;
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;
    if (TProp* P = CastField<TProp>(Prop))
    {
        Out = P->GetPropertyValue_InContainer(Target);
        return true;
    }
    return false;
}

static bool GetStruct(UObject* Target, FName PropertyName, UScriptStruct* S, void* Dest, SIZE_T Size)
{
    if (!Target || !S) return false;
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FStructProperty* SP = CastField<FStructProperty>(Prop))
    {
        if (SP->Struct == S)
        {
            void* Src = SP->ContainerPtrToValuePtr<void>(Target);
            FMemory::Memcpy(Dest, Src, Size);
            return true;
        }
    }
    return false;
}

static bool GetObject(UObject* Target, FName PropertyName, UObject*& OutValue)
{
    if (!Target) return false;
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop) return false;

    if (FObjectProperty* OP = CastField<FObjectProperty>(Prop))
    {
        OutValue = OP->GetObjectPropertyValue(OP->ContainerPtrToValuePtr<void>(Target));
        return true;
    }
    return false;
}


// ---------- Setters (Public API) ----------

bool UVarByNameLite::SetFloatPropertyByName(UObject* Target, FName PropertyName, float Value, bool bNotifyEditor)
{
    return SetAnyFloat(Target, PropertyName, (double)Value, bNotifyEditor);
}

bool UVarByNameLite::SetDoublePropertyByName(UObject* Target, FName PropertyName, double Value, bool bNotifyEditor)
{
    return SetAnyFloat(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetIntPropertyByName(UObject* Target, FName PropertyName, int32 Value, bool bNotifyEditor)
{
    return SetAnyInteger(Target, PropertyName, (int64)Value, bNotifyEditor);
}

bool UVarByNameLite::SetBoolPropertyByName(UObject* Target, FName PropertyName, bool Value, bool bNotifyEditor)
{
    return SetSimple<FBoolProperty>(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetVectorPropertyByName(UObject* Target, FName PropertyName, FVector Value, bool bNotifyEditor)
{
    return SetStruct(Target, PropertyName, TBaseStructure<FVector>::Get(), &Value, sizeof(FVector), bNotifyEditor);
}

bool UVarByNameLite::SetLinearColorPropertyByName(UObject* Target, FName PropertyName, FLinearColor Value, bool bNotifyEditor)
{
    return SetStruct(Target, PropertyName, TBaseStructure<FLinearColor>::Get(), &Value, sizeof(FLinearColor), bNotifyEditor);
}

bool UVarByNameLite::SetTexturePropertyByName(UObject* Target, FName PropertyName, UTexture* Value, bool bNotifyEditor)
{
    return SetObject(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetTexture2DPropertyByName(UObject* Target, FName PropertyName, UTexture2D* Value, bool bNotifyEditor)
{
    return SetObject(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetTexture2DArrayPropertyByName(UObject* Target, FName PropertyName, UTexture2DArray* Value, bool bNotifyEditor)
{
    return SetObject(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetObjectPropertyByName(UObject* Target, FName PropertyName, UObject* Value, bool bNotifyEditor)
{
    return SetObject(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetStringPropertyByName(UObject* Target, FName PropertyName, const FString& Value, bool bNotifyEditor)
{
    return SetSimple<FStrProperty>(Target, PropertyName, Value, bNotifyEditor);
}

bool UVarByNameLite::SetNamePropertyByName(UObject* Target, FName PropertyName, FName Value, bool bNotifyEditor)
{
    return SetSimple<FNameProperty>(Target, PropertyName, Value, bNotifyEditor);
}


// ---------- Getters (Public API) ----------

void UVarByNameLite::GetFloatPropertyByName(UObject* Target, FName PropertyName, bool& bFound, float& Value)
{
    double D = 0.0; 
    bFound = GetAnyFloat(Target, PropertyName, D); 
    Value = (float)D;
}

void UVarByNameLite::GetDoublePropertyByName(UObject* Target, FName PropertyName, bool& bFound, double& Value)
{
    double D = 0.0; 
    bFound = GetAnyFloat(Target, PropertyName, D); 
    Value = D;
}

void UVarByNameLite::GetIntPropertyByName(UObject* Target, FName PropertyName, bool& bFound, int32& Value)
{
    int64 I = 0; 
    bFound = GetAnyInteger(Target, PropertyName, I); 
    Value = (int32)I;
}

void UVarByNameLite::GetBoolPropertyByName(UObject* Target, FName PropertyName, bool& bFound, bool& Value)
{
    bool V = false; 
    bFound = GetSimple<FBoolProperty, bool>(Target, PropertyName, V); 
    Value = V;
}

void UVarByNameLite::GetVectorPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FVector& Value)
{
    FVector V = FVector::ZeroVector; 
    bFound = GetStruct(Target, PropertyName, TBaseStructure<FVector>::Get(), &V, sizeof(FVector)); 
    Value = V;
}

void UVarByNameLite::GetLinearColorPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FLinearColor& Value)
{
    FLinearColor V = FLinearColor::Black; 
    bFound = GetStruct(Target, PropertyName, TBaseStructure<FLinearColor>::Get(), &V, sizeof(FLinearColor)); 
    Value = V;
}

void UVarByNameLite::GetTexturePropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture*& Value)
{
    UObject* Obj = nullptr; 
    bFound = GetObject(Target, PropertyName, Obj); 
    Value = Cast<UTexture>(Obj);
}

void UVarByNameLite::GetTexture2DPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture2D*& Value)
{
    UObject* Obj = nullptr; 
    bFound = GetObject(Target, PropertyName, Obj); 
    Value = Cast<UTexture2D>(Obj);
}

void UVarByNameLite::GetTexture2DArrayPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UTexture2DArray*& Value)
{
    UObject* Obj = nullptr; 
    bFound = GetObject(Target, PropertyName, Obj); 
    Value = Cast<UTexture2DArray>(Obj);
}

void UVarByNameLite::GetObjectPropertyByName(UObject* Target, FName PropertyName, bool& bFound, UObject*& Value)
{
    UObject* Obj = nullptr; 
    bFound = GetObject(Target, PropertyName, Obj); 
    Value = Obj;
}

void UVarByNameLite::GetStringPropertyByName(UObject* Target, FName PropertyName, bool& bFound, FString& Value)
{
    FString V; 
    bFound = GetSimple<FStrProperty, FString>(Target, PropertyName, V); 
    Value = V;
}

void UVarByNameLite::GetNamePropertyByName(UObject* Target, FName PropertyName, bool& bFound, FName& Value)
{
    FName V; 
    bFound = GetSimple<FNameProperty, FName>(Target, PropertyName, V); 
    Value = V;
}

void UVarByNameLite::GetPropertyTypeByName(UObject* Target, FName PropertyName, bool& bFound, FString& TypeName)  // Find the reflected property by name
{
    bFound = false;
    TypeName.Empty();

    if (!Target)
    {
        return;
    }
    
    FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName);
    if (!Prop)
    {
        // Collect all property names on this class for debugging
        FString AllNames;
        for (TFieldIterator<FProperty> It(Target->GetClass()); It; ++It)
        {
            AllNames += It->GetName();
            AllNames += TEXT(", ");
        }

        // Log what actually exists
        UE_LOG(LogTemp, Warning,
            TEXT("GetPropertyTypeByName: property '%s' not found on %s. Available properties: %s"),
            *PropertyName.ToString(),
            *Target->GetClass()->GetName(),
            *AllNames
        );

        return;
    }

    bFound = true;

    // Identify type based on property class
    if (Prop->IsA<FFloatProperty>())
    {
        TypeName = TEXT("Float");
    }
#if ENGINE_MAJOR_VERSION >= 5
    else if (Prop->IsA<FDoubleProperty>())
    {
        TypeName = TEXT("Double");
    }
#endif
    else if (Prop->IsA<FIntProperty>())
    {
        TypeName = TEXT("Int32");
    }
    else if (Prop->IsA<FInt64Property>())
    {
        TypeName = TEXT("Int64");
    }
    else if (Prop->IsA<FBoolProperty>())
    {
        TypeName = TEXT("Bool");
    }
    else if (FStructProperty* SP = CastField<FStructProperty>(Prop))
    {
        // For structs, give the actual struct name (e.g. Vector, LinearColor)
        TypeName = FString::Printf(TEXT("Struct %s"), *SP->Struct->GetName());
    }
    else if (FObjectProperty* OP = CastField<FObjectProperty>(Prop))
    {
        // For objects, give the class name of the referenced object
        TypeName = FString::Printf(TEXT("Object %s"), *OP->PropertyClass->GetName());
    }
    else if (Prop->IsA<FStrProperty>())
    {
        TypeName = TEXT("String");
    }
    else if (Prop->IsA<FNameProperty>())
    {
        TypeName = TEXT("Name");
    }
    else if (Prop->IsA<FTextProperty>())
    {
        TypeName = TEXT("Text");
    }
    else if (Prop->IsA<FArrayProperty>())
    {
        TypeName = TEXT("Array");
    }
    else
    {
        // Fallback: just return the reflected UE class name
        TypeName = Prop->GetClass()->GetName();
    }
}

void UVarByNameLite::GetPropertyName(const int32& Var, bool& bFound, FName& PropertyName)
{
    // never called — implemented in execGetPropertyName
}

DEFINE_FUNCTION(UVarByNameLite::execGetPropertyName)
{
    Stack.MostRecentProperty = nullptr;
    Stack.MostRecentPropertyAddress = nullptr;
    Stack.Step(Stack.Object, nullptr);
    FProperty* PassedProp = Stack.MostRecentProperty;

    P_GET_UBOOL_REF(bFound);                                     // bool&
    P_GET_PROPERTY_REF(FNameProperty, PropertyName);             // FName& (aka FNameProperty::TCppType)
    P_FINISH;

    P_NATIVE_BEGIN;
    if (PassedProp)
    {
        PropertyName = PassedProp->GetFName();
        bFound = (PropertyName != NAME_None);
    }
    else
    {
        PropertyName = NAME_None;
        bFound = false;
    }
    P_NATIVE_END;
}



static void CopyObjectPropFromCDO(FObjectProperty* ObjProp, void* DestAddr, void* SrcAddr, UObject* NewOuter, bool bDuplicateInstanced)
{
    const bool bIsInstanced = ObjProp->HasAnyPropertyFlags(CPF_InstancedReference);

    if (bIsInstanced && bDuplicateInstanced)
    {
        UObject* SrcObj  = ObjProp->GetObjectPropertyValue(SrcAddr);
        UObject* Dup     = SrcObj ? DuplicateObject(SrcObj, NewOuter) : nullptr;
        ObjProp->SetObjectPropertyValue(DestAddr, Dup);
    }
    else
    {
        // Mirror the CDO pointer (or null) exactly
        ObjProp->CopyCompleteValue(DestAddr, SrcAddr);
    }
}

void UVarByNameLite::ResetDirtyProperties(UObject* Target,
                                          bool bIncludeTransient /*= true*/,
                                          bool bDuplicateInstancedSubobjects /*= true*/)
{
    if (!Target) return;

    UClass* Cls = Target->GetClass();
    UObject* CDO = Cls->GetDefaultObject();

    for (FProperty* Prop = Cls->PropertyLink; Prop; Prop = Prop->PropertyLinkNext)
    {
        // skip transients unless explicitly included
        if (!bIncludeTransient && Prop->HasAnyPropertyFlags(CPF_Transient))
        {
            continue;
        }

        // Only act if the value differs from the CDO
        if (Prop->Identical_InContainer(Target, CDO))
        {
            continue;
        }

        void* DestAddr = Prop->ContainerPtrToValuePtr<void>(Target);
        void* SrcAddr  = Prop->ContainerPtrToValuePtr<void>(CDO);

        if (FObjectProperty* ObjProp = CastField<FObjectProperty>(Prop))
        {
            CopyObjectPropFromCDO(ObjProp, DestAddr, SrcAddr, Target, bDuplicateInstancedSubobjects);
            continue;
        }

        // Generic copy (covers primitives, structs, arrays/maps/sets, soft refs, etc.)
        Prop->CopyCompleteValue(DestAddr, SrcAddr);
    }

    Target->Modify();
    if (UPackage* Pkg = Target->GetOutermost()) { Pkg->SetDirtyFlag(true); }
    FPropertyChangedEvent Dummy(nullptr, EPropertyChangeType::ValueSet);
    Target->PostEditChangeProperty(Dummy);
}

