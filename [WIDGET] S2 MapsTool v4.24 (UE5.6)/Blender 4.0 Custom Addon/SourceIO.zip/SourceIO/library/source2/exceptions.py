class MissingBlock(Exception):
    pass
