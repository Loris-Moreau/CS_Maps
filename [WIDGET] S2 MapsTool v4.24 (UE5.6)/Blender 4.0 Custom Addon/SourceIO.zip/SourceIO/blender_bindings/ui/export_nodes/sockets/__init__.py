from .bodygroup_socket import SourceIOBodygroupSocket
from .material_socket import SourceIOMaterialSocket
from .object_socket import SourceIOObjectSocket
from .skin_socket import *
from .texture_socket import *
