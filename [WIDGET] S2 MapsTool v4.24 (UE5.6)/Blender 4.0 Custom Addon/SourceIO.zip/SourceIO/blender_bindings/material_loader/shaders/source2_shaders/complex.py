from .vr_complex import VrComplex


class Complex(VrComplex):
    SHADER: str = 'complex.vfx'