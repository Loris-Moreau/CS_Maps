# TODO LIST:
* [ ] Better overlays and decals import
* [ ] Source1 animations support
* [ ] Source2 animations support
* [x] Source2 RGBA16161616F textures support
* [ ] Add more TODO items